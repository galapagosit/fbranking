#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/fbranking" -importPath github.com/galapagosit/fbranking -srcPath "$SCRIPTPATH/src" -runMode prod
